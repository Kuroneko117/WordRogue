extends Control

const Actor = preload("res://scripts/ui/actor_view.gd")
const Profiles = preload("res://scripts/presentation_profiles.gd")
const MomentumView = preload("res://scripts/ui/momentum_view.gd")
var momentum_view: HBoxContainer
var player_avatar: Control
var enemy_avatar: Control
var player_bar: ProgressBar
var enemy_bar: ProgressBar
var hp_label: Label
var enemy_hp_label: Label
var combo_label: Label
var word_label: Label
var phonetic_label: Label
var feedback_label: Label
var encounter_label: Label
var weak_label: Label
var spell_card: PanelContainer
var answer_buttons: Array[Button] = []
var spell_buttons: Dictionary = {}
var resource_label: Label
var intent_label: Label
var status_label: Label
var enemy_name: Label
var word_class: Label
var host: Control

const Kit = preload("res://scripts/ui/ui_kit.gd")
const Journal = preload("res://scripts/ui/journal_screens.gd")
var danger_label: Label

func build(main: Control) -> void:
	host = main
	z_index = 1
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var page := Kit.page(self,95)
	page.add_theme_constant_override("separation",12)
	var enemy: Dictionary = GameState.current_enemy()
	var kind := str(enemy.kind)
	var layer := int(GameState.route.NODES[GameState.route.active].layer) if not GameState.route.active.is_empty() else GameState.battle_index+1
	var header := Kit.row(page)
	Kit.text(header,"第 %d / %d 层 · %s" % [layer,GameState.route.depth,"最终首领" if kind == "boss" else ("精英遭遇" if kind == "elite" else ("入口遭遇" if layer == 1 else "藏书回廊"))],32,Kit.GOLD).size_flags_horizontal = Control.SIZE_EXPAND_FILL
	Kit.text(header,str(GameState.Difficulty.get_mode(GameState.difficulty_id).name),25,Kit.MUTED)
	var settings := Kit.button(host,header,"暂停" if host.PlatformUI.touch_mode() else "ESC 暂停",host.pause_menu.open_menu)
	settings.size_flags_horizontal = Control.SIZE_FILL
	settings.custom_minimum_size = Vector2(205,56)
	var arena := Kit.row(page,26)
	arena.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var left := _column(arena,1.15)
	var middle := _column(arena,1.8)
	var right := _column(arena,1.65 if kind == "boss" else 1.2)
	middle.z_index = 5
	for column in [left,middle,right]: column.add_theme_constant_override("separation",12)
	middle.add_theme_constant_override("separation",10)
	var player_panel := Kit.card(left,Kit.BLUE)
	player_panel.add_theme_stylebox_override("panel",Kit.style(Kit.CARD,Kit.BLUE,16))
	var player_stats := Kit.column(player_panel,6)
	var player_heading := Kit.row(player_stats,8)
	Kit.text(player_heading,"单词法师",32,Kit.BLUE)
	combo_label = Kit.text(player_heading,"连击 ×0",32,Kit.GOLD)
	hp_label = Kit.text(player_stats,"生命 %d / %d" % [GameState.hp,GameState.max_hp],27)
	player_bar = _health_bar(player_stats,GameState.max_hp,GameState.hp,Kit.BLUE,22)
	resource_label = Kit.text(player_stats,"",27,Kit.BLUE)
	status_label = Kit.text(player_stats,"",22,Kit.MUTED)
	player_avatar = Actor.new()
	player_avatar.custom_minimum_size.y = 330
	player_avatar.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left.add_child(player_avatar)
	var hero := Journal.hero_path()
	player_avatar.setup("mage",hero,Kit.BLUE)
	player_avatar.texture_height = 435
	player_avatar.texture_padding = Vector2(32,40)
	player_avatar.floor_padding = 24
	if hero.ends_with("word_mage_v2.png"): player_avatar.cast_uv = Vector2(0.84,0.205)
	spell_card = Kit.card(middle,Kit.GOLD)
	var spell_style := Kit.style(Kit.CARD,Kit.GOLD,24)
	spell_style.content_margin_top = 12
	spell_style.content_margin_bottom = 12
	spell_card.add_theme_stylebox_override("panel",spell_style)
	var spell := Kit.column(spell_card,4)
	word_class = Kit.text(spell,"单词法术",22,Kit.GOLD,true)
	word_label = Kit.text(spell,"",58,Kit.PAPER,true)
	word_label.custom_minimum_size.y = 76
	phonetic_label = Kit.text(spell,"",28,Kit.MUTED,true)
	weak_label = Kit.text(middle,"",23,Kit.RED,true)
	weak_label.custom_minimum_size.y = 24
	var spells := Kit.row(middle,8)
	for id in ["arcane","aegis","memory"]:
		var info: Dictionary = GameState.SPELLS[id]
		var key: String = {"arcane":"Q","aegis":"W","memory":"E"}[id]
		var brief: String = {"arcane":"全伤 / +1法力","aegis":"全伤 / +8盾","memory":"180% / 错词+5"}[id]
		var button := Kit.button(host,spells,"[%s] %s\n%d法力 · %s" % [key,str(info.name),int(info.cost),brief],host._select_spell.bind(str(id)))
		button.custom_minimum_size.y = 104
		button.add_theme_font_size_override("font_size",23)
		button.tooltip_text = {"arcane":"答对获得1法力，答错受到反击。", "aegis":"答对造成完整普通伤害并获得护盾，护盾优先吸收伤害；答错减伤30%。", "memory":"答对造成普通伤害180%；本局之前答错的词额外加伤。"}[id]
		spell_buttons[str(id)] = button
	feedback_label = Kit.text(middle,"请选择正确释义",27,Kit.GOLD,true)
	feedback_label.custom_minimum_size.y = 58
	feedback_label.add_theme_stylebox_override("normal",Kit.style(Kit.INK,Color.TRANSPARENT,8))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation",14)
	grid.add_theme_constant_override("v_separation",14)
	middle.add_child(grid)
	for i in 4:
		var button := Kit.button(host,grid,"",host._on_answer.bind(i))
		button.custom_minimum_size.y = 100
		button.add_theme_font_size_override("font_size",29)
		answer_buttons.append(button)
	Kit.text(middle,"点击选择法术，再点击正确释义" if host.PlatformUI.touch_mode() else "1–4 作答 · Q/W/E 选择法术 · Tab/方向键导航",22,Kit.MUTED,true)
	var enemy_panel := Kit.card(right,Kit.RED)
	enemy_panel.add_theme_stylebox_override("panel",Kit.style(Kit.CARD,Kit.RED,16))
	var enemy_stats := Kit.column(enemy_panel,6)
	enemy_name = Kit.text(enemy_stats,str(enemy.subtitle),34 if kind == "boss" else 31,Kit.RED)
	Kit.text(enemy_stats,"最终首领" if kind == "boss" else ("精英敌人" if kind == "elite" else "普通敌人"),22,Kit.MUTED)
	enemy_hp_label = Kit.text(enemy_stats,"生命 %d / %d" % [GameState.enemy_hp,int(enemy.hp)],27)
	enemy_bar = _health_bar(enemy_stats,int(enemy.hp),GameState.enemy_hp,Kit.RED,26)
	momentum_view = MomentumView.new()
	enemy_stats.add_child(momentum_view)
	enemy_avatar = Actor.new()
	enemy_avatar.custom_minimum_size.y = 380
	enemy_avatar.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(enemy_avatar)
	var image := str(enemy.get("art","librarian" if kind == "boss" else ("marginalia" if kind == "elite" else "ink_wraith")))
	var portrait: Dictionary = Profiles.PORTRAITS.get(str(enemy.get("id","")),{})
	if not portrait.is_empty(): image = str(portrait.art)
	if not ResourceLoader.exists("res://assets/enemies/%s.png" % image) and not str(portrait.get("fallback","")).is_empty(): image = str(portrait.fallback)
	enemy_avatar.setup(kind,"res://assets/enemies/%s.png" % image if not image.is_empty() else "",Kit.RED)
	if not enemy_avatar.uses_texture and enemy.has("id"):
		enemy_avatar.art.kind = str(enemy.id)
		enemy_avatar.art.queue_redraw()
	enemy_avatar.texture_padding = Vector2(40,32)
	enemy_avatar.floor_padding = 24
	enemy_avatar.texture_height = float(portrait.get("height",610 if kind == "boss" else (510 if kind == "elite" else 480)))
	# Put tactical text outside the actor columns: long warnings must not
	# shrink the enemy while leaving the player at a different scale.
	var footer_panel := Kit.card(page)
	footer_panel.add_theme_stylebox_override("panel",Kit.style(Kit.CARD,Color("#43536b"),16))
	footer_panel.custom_minimum_size.y = 136
	var footer := Kit.row(footer_panel,24)
	var statistics := Kit.column(footer,8)
	statistics.custom_minimum_size.x = 250
	Kit.text(statistics,"攻击 %d" % GameState.base_attack,26,Kit.GOLD)
	encounter_label = Kit.text(statistics,"本局已答题 %d" % GameState.questions_answered(),25,Kit.MUTED)
	danger_label = Kit.text(footer,"",24,Kit.MUTED)
	danger_label.size_flags_stretch_ratio = 1.0
	danger_label.custom_minimum_size.y = 104
	intent_label = Kit.text(footer,"",24,Kit.PAPER)
	intent_label.size_flags_stretch_ratio = 1.5
	intent_label.custom_minimum_size.y = 104
	update_spells(true)

func update_spells(waiting: bool) -> void:
	resource_label.text = "法力 %d/%d · 护盾 %d" % [GameState.mana,GameState.max_mana,GameState.barrier]
	for id in spell_buttons:
		var button: Button = spell_buttons[id]
		var selected: bool = id == GameState.selected_spell
		button.disabled = not waiting or not GameState.can_cast(str(id))
		var effect: String = {"arcane":"答对 +1法力","aegis":"护盾 +%d" % (10 if GameState.rewards.has("aegis_edge") else 8),"memory":"旧错词额外 +%d" % (10 if GameState.rewards.has("resonance") else 5)}[id]
		var key: String = {"arcane":"Q","aegis":"W","memory":"E"}[id]
		var cost := "%d法力 · %s伤害" % [int(GameState.SPELLS[id].cost),"180%" if id == "memory" else "100%"] if GameState.can_cast(str(id)) else "法力不足 · 需要%d" % int(GameState.SPELLS[id].cost)
		var prefix := "" if host.PlatformUI.touch_mode() else "[%s] " % key
		button.text = "%s%s\n%s\n%s" % [prefix,str(GameState.SPELLS[id].name),cost,effect]
		button.add_theme_color_override("font_color",Kit.GOLD if selected else Kit.PAPER)
		button.add_theme_stylebox_override("normal",host._style(Color("#4a5145") if selected else Color("#202d39"),host.GOLD if selected else Color("#46505c")))
		button.add_theme_stylebox_override("disabled",host._style(Color("#1b232c"),host.GOLD if selected else Color("#383f49")))
	if waiting: update_intent()
	update_status()

func update_intent() -> void:
	if GameState.enemy_intent.is_empty(): return
	var intent: Dictionary = GameState.enemy_intent
	var preview: Dictionary = GameState.incoming_preview()
	var rider := " · 附墨蚀" if intent.effect == "ink" else (" · 封印1法力" if intent.effect == "seal" else "")
	intent_label.text = "意图：%s\n%d伤害 · 预计扣血%d%s" % [str(intent.name),int(preview.reduced),int(preview.hp_damage),rider]
	danger_label.text = "答对打断攻击 · 答错受到反击"
	danger_label.add_theme_color_override("font_color",Kit.MUTED)
	if bool(intent.get("uninterruptible",false)) and not GameState.classic_fixture:
		danger_label.text = "不可打断！\n答对仍造成伤害，未击杀将遭反击。"
		danger_label.add_theme_color_override("font_color",Kit.RED)
		var right: Dictionary = GameState.incoming_preview("arcane",true)
		intent_label.tooltip_text = "答对预计受到%d伤害；守护先加盾再承受反击；击杀可取消反击。" % int(right.typed)
	else: intent_label.tooltip_text = "答对打断普通攻击；守护答错减伤30%；护盾优先吸收伤害。"
	if preview.immune: intent_label.text += "\n学者之盾可免疫答错"
	elif GameState.selected_spell == "aegis": intent_label.text += "\n守护答错减伤30%"
	update_status()

func update_status() -> void:
	status_label.text = "墨蚀 / 下题答错额外+3伤害" if GameState.ink_active else "状态正常"
	if GameState.boss_phase_two: enemy_name.text = "遗忘图书管理员 · 第二阶段"
	if is_instance_valid(momentum_view):
		momentum_view.visible = not GameState.classic_fixture
		var pending := not GameState.intent_consumed and bool(GameState.enemy_intent.get("uninterruptible",false))
		momentum_view.display(GameState.momentum.value,GameState.momentum.threshold,not GameState.classic_fixture and (GameState.momentum.ready() or pending),GameState.momentum.cooldown)

func _column(parent: HBoxContainer, ratio: float) -> VBoxContainer:
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.size_flags_stretch_ratio = ratio
	column.add_theme_constant_override("separation", 12)
	parent.add_child(column)
	return column

func _text(parent: Node, value: String, font_size: int, color: Color, center: bool = false) -> Label:
	var label := Label.new()
	label.text = value
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if center else HORIZONTAL_ALIGNMENT_LEFT
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	parent.add_child(label)
	return label

func _health_bar(parent: Control, maximum: int, value: int, color: Color, height: int) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.max_value = maximum
	bar.value = value
	bar.show_percentage = false
	bar.custom_minimum_size.y = height
	bar.add_theme_stylebox_override("background", host._style(Color("#101721"), Color("#4e4650"), 8))
	bar.add_theme_stylebox_override("fill", host._style(color, Color.TRANSPARENT, 8))
	parent.add_child(bar)
	return bar
