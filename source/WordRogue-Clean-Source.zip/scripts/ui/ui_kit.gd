extends RefCounted

const INK := Color("#101a28")
const CARD := Color("#1b2939")
const GOLD := Color("#d9b575")
const PAPER := Color("#f3ead6")
const MUTED := Color("#a8b5c4")
const BLUE := Color("#85d7e7")
const RED := Color("#e38698")

static func style(fill: Color, edge: Color = Color("#43536b"), padding: int = 24) -> StyleBoxFlat:
	var result := StyleBoxFlat.new()
	result.bg_color = fill
	result.border_color = edge
	result.set_border_width_all(2)
	result.set_corner_radius_all(14)
	result.content_margin_left = padding
	result.content_margin_right = padding
	result.content_margin_top = padding
	result.content_margin_bottom = padding
	return result

static func make_theme(font: Font) -> Theme:
	var result := Theme.new()
	result.default_font = font
	result.default_font_size = 28
	result.set_stylebox("panel","PanelContainer",style(CARD))
	result.set_stylebox("normal","Button",style(CARD,Color("#566078"),18))
	result.set_stylebox("hover","Button",style(Color("#2c3c51"),GOLD,18))
	result.set_stylebox("pressed","Button",style(Color("#384453"),BLUE,18))
	result.set_stylebox("disabled","Button",style(Color("#172230"),Color("#354255"),18))
	result.set_stylebox("focus","Button",style(Color.TRANSPARENT,BLUE,2))
	result.set_color("font_color","Button",PAPER)
	result.set_color("font_disabled_color","Button",MUTED)
	result.set_color("font_color","Label",PAPER)
	result.set_constant("separation","VBoxContainer",16)
	result.set_constant("separation","HBoxContainer",20)
	return result

static func page(parent: Control, top: int = 100) -> VBoxContainer:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for pair in [["left",64],["right",64],["top",top],["bottom",42]]:
		margin.add_theme_constant_override("margin_"+str(pair[0]),int(pair[1]))
	parent.add_child(margin)
	return column(margin,20)

static func column(parent: Node, gap: int = 16, expand: bool = false) -> VBoxContainer:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",gap)
	if expand:
		box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	parent.add_child(box)
	return box

static func row(parent: Node, gap: int = 20) -> HBoxContainer:
	var box := HBoxContainer.new()
	box.add_theme_constant_override("separation",gap)
	parent.add_child(box)
	return box

static func card(parent: Node, edge: Color = Color("#43536b"), expand: bool = false) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel",style(CARD,edge))
	if expand: panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(panel)
	return panel

static func text(parent: Node, value: String, size: int = 28, color: Color = PAPER, center: bool = false) -> Label:
	var label := Label.new()
	label.text = value
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if center else HORIZONTAL_ALIGNMENT_LEFT
	label.add_theme_font_size_override("font_size",size)
	label.add_theme_color_override("font_color",color)
	parent.add_child(label)
	return label

static func button(host: Control, parent: Control, caption: String, callback: Callable, primary: bool = false) -> Button:
	var item: Button = host._button(parent,caption,Vector2.ZERO,Vector2.ZERO,callback,Color("#665138") if primary else CARD)
	item.custom_minimum_size.y = 72
	item.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	item.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if host.get_viewport().gui_get_focus_owner() == null: item.grab_focus()
	return item

static func space(parent: Node) -> Control:
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	parent.add_child(spacer)
	return spacer

static func disable_buttons(node: Node) -> void:
	if node is BaseButton: node.disabled = true
	for child in node.get_children(): disable_buttons(child)
