extends Control
const Icon = preload("res://scripts/ui/map_icon.gd")
var category := "进攻"
var accent := Color("#d8ae69")

func _draw() -> void:
	draw_set_transform(size/2.0)
	draw_circle(Vector2.ZERO,41,Color(accent,0.07))
	draw_arc(Vector2.ZERO,41,0,TAU,48,Color(accent,0.35),1.5,true)
	Icon.draw_symbol(self,category,accent)
