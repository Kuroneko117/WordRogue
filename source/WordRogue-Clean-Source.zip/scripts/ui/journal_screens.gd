extends RefCounted

const Kit = preload("res://scripts/ui/ui_kit.gd")
const Actor = preload("res://scripts/ui/actor_view.gd")
const Badge = preload("res://scripts/ui/reward_badge.gd")

static func title(host: Control) -> void:
	var page := Kit.page(host,130)
	var row := Kit.row(page,60)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var panel := Kit.card(row,Kit.GOLD,true)
	panel.size_flags_stretch_ratio = 1.35
	var box := Kit.column(panel,24)
	Kit.space(box)
	Kit.text(box,"WORDROGUE  /  V1.9",24,Kit.GOLD)
	Kit.text(box,"遗忘书塔",86)
	Kit.text(box,"单词就是你的武器。",34,Kit.BLUE)
	Kit.text(box,"七层书塔 · 三种法术 · 一次记忆试炼\n被遗忘的词汇，将再次成为你的敌人。",28,Kit.MUTED)
	Kit.space(box)
	var start := Kit.button(host,box,"开始冒险  →",host._start_adventure,true)
	start.disabled = not WordBank.load_error.is_empty()
	if start.disabled: Kit.text(box,WordBank.load_error,24,Kit.RED)
	var actions := Kit.row(box)
	Kit.button(host,actions,"声音设置",host.open_title_settings)
	Kit.button(host,actions,"退出游戏",host.request_quit)
	Kit.space(box)
	var art := Actor.new()
	art.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	art.size_flags_stretch_ratio = 1.0
	row.add_child(art)
	art.setup("mage",hero_path(),Kit.BLUE)
	art.texture_height = 790
	Kit.text(page,"Words are your weapons.  ·  掌握度自动保存在本地" if host.PlatformUI.touch_mode() else "Words are your weapons.  ·  掌握度自动保存在本地  ·  ESC 设置",23,Kit.MUTED,true)
	if not SaveData.load_warning.is_empty(): Kit.text(page,SaveData.load_warning,22,Kit.RED,true)
	start.grab_focus()

static func hero_path(preferred: String = "res://assets/characters/word_mage_v2.png") -> String:
	return preferred if ResourceLoader.exists(preferred) else "res://assets/characters/word_mage.png"

static func difficulty(host: Control) -> void:
	var page := Kit.page(host,145)
	Kit.text(page,"选择你的试炼",58,Kit.GOLD)
	Kit.text(page,"每局七层，词汇掌握度跨难度保留。普通难度目标 7–10 分钟。",28,Kit.MUTED)
	Kit.space(page)
	var cards := Kit.row(page,26)
	cards.custom_minimum_size.y = 490
	for id in ["easy","normal","hard"]:
		var mode: Dictionary = GameState.Difficulty.get_mode(id)
		var panel := Kit.card(cards,Kit.GOLD if id == "normal" else Color("#657088"),true)
		var box := Kit.column(panel,22)
		Kit.text(box,"推荐试炼" if id == "normal" else ("初次入塔" if id == "easy" else "挑战记忆"),24,Kit.BLUE)
		Kit.text(box,str(mode.name),38,Kit.GOLD)
		Kit.text(box,str(mode.pool),28)
		Kit.text(box,str(mode.hint),26,Kit.MUTED).custom_minimum_size.y = 145
		Kit.space(box)
		var button := Kit.button(host,box,"进入书塔",host._begin_run.bind(id),id == "normal")
		if id == "normal": button.grab_focus()
	Kit.space(page)
	Kit.button(host,page,"← 返回标题",host.show_title)

static func reward(host: Control) -> void:
	var page := Kit.page(host,130)
	var treasure: bool = not GameState.route.active.is_empty() and GameState.route.NODES[GameState.route.active].kind == "treasure"
	Kit.text(page,"藏宝书架" if treasure else "战斗胜利",52,Kit.GOLD)
	Kit.text(page,"选择本局强化  ·  第 %d / %d 次" % [GameState.reward_batch-GameState.rewards_pending+1,GameState.reward_batch],30)
	Kit.text(page,"生命 %d/%d  ·  胜利恢复 %d  ·  已有遗物 %d" % [GameState.hp,GameState.max_hp,GameState.victory_healed,GameState.rewards.size()],25,Kit.MUTED)
	Kit.space(page)
	var cards := Kit.row(page,26)
	cards.custom_minimum_size.y = 475
	for item in GameState.reward_choices():
		var category: String = GameState.Catalog.tag(item)
		var accent: Color = GameState.Catalog.COLORS[category]
		var panel := Kit.card(cards,accent,true)
		host.reward_cards[str(item.id)] = panel
		var box := Kit.column(panel,20)
		Kit.text(box,category+" / "+("即时补给" if item.get("repeatable",false) else "本局遗物"),23,accent)
		var icon := Badge.new()
		icon.category = category
		icon.accent = accent
		icon.custom_minimum_size.y = 88
		box.add_child(icon)
		Kit.text(box,GameState.reward_name(str(item.id)),36,Kit.PAPER)
		var description := str(item.description).replace("Combo","连击").replace("Mastery","掌握度").replace("HP","生命")
		Kit.text(box,description,28).custom_minimum_size.y = 125
		Kit.space(box)
		var select := Kit.button(host,box,"选择此强化",host._choose_reward.bind(str(item.id)),true)
		select.tooltip_text = description
		select.mouse_entered.connect(func() -> void:
			if not host.reward_locked: panel.add_theme_stylebox_override("panel",Kit.style(Kit.CARD.lightened(0.08),Kit.GOLD)))
		select.mouse_exited.connect(func() -> void:
			if not host.reward_locked: panel.add_theme_stylebox_override("panel",Kit.style(Kit.CARD,accent)))
	Kit.space(page)
	Kit.text(page,"普通战奖励一次，精英奖励两次。遗物只在本局生效。",26,Kit.MUTED,true)

static func rest(host: Control) -> void:
	var page := Kit.page(host,170)
	var card := Kit.card(page,Kit.GOLD)
	var box := Kit.column(card,28)
	Kit.text(box,"休息书桌  /  安全房间",25,Kit.BLUE)
	Kit.text(box,"灯火尚温，记忆尚在。",52,Kit.GOLD)
	Kit.text(box,"放下魔法书休息片刻。不答题，不消耗法力。",30)
	var heal := mini(GameState.max_hp-GameState.hp,ceili(float(GameState.max_hp)*0.2))
	Kit.text(box,"生命 %d / %d  →  %d / %d\n恢复最大生命的 20%%，本次实际恢复 %d。" % [GameState.hp,GameState.max_hp,GameState.hp+heal,GameState.max_hp,heal],32,Kit.BLUE)
	Kit.button(host,box,"休息并返回地图",host._rest_and_continue,true)
	Kit.text(box,"每个休息节点仅能使用一次。",24,Kit.MUTED)

static func report(host: Control) -> void:
	var data: Dictionary = host.report_snapshot
	var won: bool = GameState.run_won and GameState.hp > 0
	var page := Kit.page(host,105)
	var heading := Kit.row(page)
	Kit.text(heading,"冒险日志 / "+("试炼完成" if won else "试炼结束"),50,Kit.GOLD if won else Kit.RED).size_flags_horizontal = Control.SIZE_EXPAND_FILL
	Kit.text(heading,"第 %d / %d 层" % [int(GameState.route.NODES[GameState.route.current].layer),GameState.route.depth],28,Kit.MUTED)
	Kit.text(page,str(data.difficulty)+" · "+str(data.word_pool)+(" · 你找回了遗忘的词。" if won else " · 游戏失败，学习收获依然保留。"),26,Kit.MUTED)
	var metrics := Kit.row(page,14)
	var names := ["正确率","答题总数","不同单词","答对","答错","最高连击"]
	var values := [str(data.accuracy)+"%",str(data.questions_answered),str(data.unique_words),str(data.correct),str(data.wrong),"×"+str(data.best_combo)]
	for i in 6:
		var box := Kit.column(Kit.card(metrics,Kit.BLUE if i == 0 else Color("#43536b"),true),8)
		Kit.text(box,str(names[i]),24,Kit.MUTED,true)
		Kit.text(box,str(values[i]),46,Kit.BLUE if i == 0 else Kit.GOLD,true)
	Kit.text(page,"战斗 %d  ·  书房 %d  ·  事件 %d    /    答题总数 = 答对 + 答错" % [GameState.combat_answers,GameState.review_answers,GameState.event_answers],23,Kit.MUTED)
	var columns := Kit.row(page,24)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var improved := Kit.column(Kit.card(columns,Color("#73b894"),true),12)
	var weak := Kit.column(Kit.card(columns,Kit.RED,true),12)
	Kit.text(improved,"找回的记忆 / 本局提升",32,Color("#8fdbb0"))
	Kit.text(weak,"下次的对手 / 需要复习",32,Kit.RED)
	var gains: Array = GameState.improved_words()
	if gains.is_empty(): Kit.text(improved,"还没有提升词，下一次仍是新的机会。",27,Kit.MUTED)
	for item in gains: Kit.text(improved,"%s    %d → %d" % [str(item.word),int(item.before),int(item.after)],29)
	var words: Array = GameState.weak_words()
	if words.is_empty(): Kit.text(weak,"本局没有作答记录。",27,Kit.MUTED)
	for item in words: Kit.text(weak,"%s    掌握度 %d" % [str(item.word),int(item.mastery)],29)
	var actions := Kit.row(page,24)
	Kit.button(host,actions,"再来一局  →",host._start_adventure,true)
	Kit.button(host,actions,"返回标题",host.return_to_title)
